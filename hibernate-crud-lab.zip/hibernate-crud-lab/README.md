# Hibernate CRUD Operations Lab

## Aim
Implement CRUD operations using Hibernate ORM with JPA annotations,
applied to a product inventory system.

---

## Project Structure

```
hibernate-crud-lab/
├── pom.xml
└── src/main/
    ├── java/com/lab/hibernate/
    │   ├── entity/Product.java         Tasks 1 & 2 – Entity + JPA annotations
    │   ├── dao/ProductDAO.java         Tasks 3–6  – All CRUD operations
    │   ├── util/HibernateUtil.java     Singleton SessionFactory helper
    │   └── main/Main.java             Entry point – runs all tasks
    └── resources/hibernate.cfg.xml    DB connection + schema settings
```

---

## How to Run

### Prerequisites
- Java 17+ and Maven 3.6+

```bash
# Clone, then compile and run (H2 in-memory DB by default)
git clone https://github.com/your-username/hibernate-crud-lab.git
cd hibernate-crud-lab
mvn compile exec:java
```

No database installation needed for the default H2 setup.

---

## Switch to MySQL

1. Edit `hibernate.cfg.xml` – comment OPTION A, uncomment OPTION B, set password
2. Edit `pom.xml` – comment H2 dependency, uncomment mysql-connector-j
3. `CREATE DATABASE productdb;` in MySQL
4. `mvn compile exec:java`

---

## Task Reference

| Task | File | What to look at |
|------|------|-----------------|
| 1 & 2 Entity + annotations | `Product.java` | `@Entity @Table @Id @Column` |
| 3 Insert | `ProductDAO.insertProduct()` | `session.persist()` |
| 4 Retrieve | `ProductDAO.getProductById()` | `session.get()` |
| 5 Update | `ProductDAO.updateProduct()` | Hibernate dirty-checking |
| 6 Delete | `ProductDAO.deleteProduct()` | `session.remove()` |
| 7 ID strategies | `Product.java` comments | `AUTO / IDENTITY / SEQUENCE` |
| 8 GitHub | below | git commands |

---

## Task 8 – Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Hibernate CRUD Operations Lab"
git remote add origin https://github.com/your-username/hibernate-crud-lab.git
git branch -M main
git push -u origin main
```

---

## Task 7 – ID Generation Strategies

Switch between the three `@Id` blocks in `Product.java`:

| Strategy | Best for |
|----------|----------|
| `AUTO` | Portable / general use |
| `IDENTITY` | MySQL, H2, SQL Server |
| `SEQUENCE` | Oracle, PostgreSQL |
