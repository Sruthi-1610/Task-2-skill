package com.lab.hibernate.entity;

import jakarta.persistence.*;

/**
 * Product.java
 * ------------
 * JPA Entity class mapped to the "products" table in the database.
 *
 * Key JPA Annotations used:
 *   @Entity  – marks this class as a Hibernate-managed database entity
 *   @Table   – maps the class to a specific database table name
 *   @Id      – designates the primary key field
 *   @Column  – customises column name, nullability, and length
 */
@Entity
@Table(name = "products")
public class Product {

    /*
     * ── Task 7: ID Generation Strategies ──────────────────────────────────
     * Only ONE @Id block should be active at a time.
     * Comment/uncomment the desired strategy below and recompile.
     *
     *  AUTO     – Hibernate automatically selects the best strategy for the
     *             configured database. Simple and portable; good default choice.
     *
     *  IDENTITY – Relies on the database auto-increment column.
     *             Used with MySQL, SQL Server, H2.
     *             Hibernate issues INSERT first, then reads the generated key.
     *
     *  SEQUENCE – Uses a named database sequence object.
     *             Used with Oracle and PostgreSQL.
     *             More efficient for batch inserts than IDENTITY.
     *             Requires the sequence to exist in the database first.
     */

    // ── Strategy 1: AUTO (currently active) ──────────────────────────────
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    // ── Strategy 2: IDENTITY (uncomment to use) ───────────────────────────
    // @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY)
    // private int id;

    // ── Strategy 3: SEQUENCE (uncomment to use; sequence must exist in DB) ─
    // @Id
    // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_seq")
    // @SequenceGenerator(
    //     name           = "product_seq",         // generator alias used above
    //     sequenceName   = "PRODUCT_SEQUENCE",     // actual sequence name in DB
    //     allocationSize = 1                       // increment by 1 each time
    // )
    // private int id;

    // ── Column Mappings ────────────────────────────────────────────────────

    @Column(name = "name", nullable = false, length = 100)
    private String name;          // product name – required, max 100 chars

    @Column(name = "description", length = 255)
    private String description;   // optional short description, max 255 chars

    @Column(name = "price", nullable = false)
    private double price;         // unit price, e.g. 299.99

    @Column(name = "quantity", nullable = false)
    private int quantity;         // units currently in stock

    // ── Constructors ───────────────────────────────────────────────────────

    /**
     * No-arg constructor required by the JPA/Hibernate specification.
     * Hibernate uses this to instantiate objects when loading from the DB.
     */
    public Product() {}

    /**
     * Convenience constructor for creating a new product before persisting.
     * The 'id' field is intentionally excluded – Hibernate generates it.
     *
     * @param name        product name
     * @param description short description
     * @param price       unit price
     * @param quantity    stock quantity
     */
    public Product(String name, String description, double price, int quantity) {
        this.name        = name;
        this.description = description;
        this.price       = price;
        this.quantity    = quantity;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────

    public int    getId()                            { return id; }
    public void   setId(int id)                      { this.id = id; }

    public String getName()                          { return name; }
    public void   setName(String name)               { this.name = name; }

    public String getDescription()                   { return description; }
    public void   setDescription(String description) { this.description = description; }

    public double getPrice()                         { return price; }
    public void   setPrice(double price)             { this.price = price; }

    public int    getQuantity()                      { return quantity; }
    public void   setQuantity(int quantity)          { this.quantity = quantity; }

    // ── toString ───────────────────────────────────────────────────────────

    /**
     * Human-readable representation used when printing product details.
     * Hibernate also uses this internally in some log messages.
     */
    @Override
    public String toString() {
        return String.format(
            "Product { id=%d, name='%s', description='%s', price=%.2f, quantity=%d }",
            id, name, description, price, quantity
        );
    }
}
