package com.lab.hibernate.util;

import com.lab.hibernate.entity.Product;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * HibernateUtil.java
 * ------------------
 * Utility class that creates and exposes a single shared SessionFactory
 * using the Singleton design pattern.
 *
 * Why Singleton?
 *   SessionFactory is a heavyweight object (holds connection pool, caches,
 *   metadata). Creating it repeatedly wastes memory and time. One instance
 *   is created once at startup and reused throughout the application.
 *
 * SessionFactory vs Session:
 *   SessionFactory – thread-safe; created once; lives for the app's lifetime.
 *   Session        – NOT thread-safe; created per unit-of-work (per transaction);
 *                    must be closed after use to return the connection to the pool.
 */
public class HibernateUtil {

    // The single shared SessionFactory instance (lazy-initialised)
    private static SessionFactory sessionFactory;

    // Private constructor prevents anyone from creating instances
    private HibernateUtil() {}

    /**
     * Returns the shared SessionFactory.
     * Creates it on the very first call (lazy initialisation).
     *
     * Configuration steps performed on first call:
     *   1. Reads hibernate.cfg.xml from the classpath (src/main/resources).
     *   2. Registers the Product entity so Hibernate knows about its mapping.
     *   3. Builds the SessionFactory (validates config, sets up connection pool).
     *
     * @return the application-wide SessionFactory
     */
    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            sessionFactory = new Configuration()
                    .configure("hibernate.cfg.xml")    // load DB settings
                    .addAnnotatedClass(Product.class)  // register entity class
                    .buildSessionFactory();
        }
        return sessionFactory;
    }

    /**
     * Closes the SessionFactory and releases all database connections.
     * Call this once when the application is shutting down.
     * Skips gracefully if already closed.
     */
    public static void shutdown() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
            System.out.println("Hibernate SessionFactory closed.");
        }
    }
}
