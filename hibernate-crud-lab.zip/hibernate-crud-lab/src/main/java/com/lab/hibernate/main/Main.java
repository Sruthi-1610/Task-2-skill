package com.lab.hibernate.main;

import com.lab.hibernate.dao.ProductDAO;
import com.lab.hibernate.entity.Product;
import com.lab.hibernate.util.HibernateUtil;

import java.util.List;

/**
 * Main.java
 * ---------
 * Application entry point for the Hibernate CRUD Operations lab.
 *
 * Executes all tasks in order to demonstrate the full CRUD lifecycle:
 *
 *   Task 3 – Insert multiple product records
 *   Task 4 – Retrieve a product by ID
 *   Task 5 – Update product price and quantity
 *   Task 6 – Delete a discontinued product
 *   Task 7 – ID generation strategy is configured in Product.java
 *
 * Run with:  mvn compile exec:java
 */
public class Main {

    public static void main(String[] args) {

        ProductDAO dao = new ProductDAO();

        System.out.println("========================================");
        System.out.println("  Hibernate CRUD Operations Lab");
        System.out.println("========================================\n");

        // ── Task 3: INSERT multiple products ──────────────────────────────
        // Each Product is created without an id – Hibernate generates it.
        // After insertProduct() returns, calling p.getId() gives the new DB id.
        System.out.println("--- Task 3: Inserting Products ---");

        Product p1 = new Product("Laptop",   "High-performance laptop",  75000.00, 10);
        Product p2 = new Product("Mouse",    "Wireless optical mouse",    1500.00, 50);
        Product p3 = new Product("Keyboard", "Mechanical RGB keyboard",   3500.00, 30);
        Product p4 = new Product("Monitor",  "27-inch 4K display",       25000.00, 15);
        Product p5 = new Product("USB Hub",  "7-port USB 3.0 hub (disc)", 2200.00,  5); // to be deleted

        dao.insertProduct(p1);
        dao.insertProduct(p2);
        dao.insertProduct(p3);
        dao.insertProduct(p4);
        dao.insertProduct(p5);  // this product will be deleted in Task 6
        System.out.println();

        // ── Task 4: RETRIEVE product by ID ────────────────────────────────
        // p1.getId() returns the auto-generated key assigned during insert.
        System.out.println("--- Task 4: Retrieve Product by ID ---");
        dao.getProductById(p1.getId());  // retrieve Laptop
        dao.getProductById(p3.getId());  // retrieve Keyboard
        dao.getProductById(999);         // retrieve non-existent → returns null
        System.out.println();

        // ── Retrieve ALL (read all before updates for comparison) ──────────
        System.out.println("--- All Products Before Update ---");
        List<Product> before = dao.getAllProducts();
        if (before != null) before.forEach(System.out::println);
        System.out.println();

        // ── Task 5: UPDATE price and quantity ─────────────────────────────
        // Hibernate's dirty-checking detects field changes and issues UPDATE.
        System.out.println("--- Task 5: Update Price & Quantity ---");
        dao.updateProduct(p1.getId(), 68000.00, 12); // Laptop: price cut + restocked
        dao.updateProduct(p2.getId(),  1200.00, 75); // Mouse:  discount + more stock
        System.out.println();

        // ── Task 6: DELETE discontinued product ───────────────────────────
        // USB Hub (p5) is discontinued – remove it from the inventory.
        System.out.println("--- Task 6: Delete Discontinued Product ---");
        dao.deleteProduct(p5.getId());
        System.out.println();

        // ── Final state: show remaining inventory ─────────────────────────
        System.out.println("--- Final Product List After All Operations ---");
        List<Product> finalList = dao.getAllProducts();
        if (finalList != null) finalList.forEach(System.out::println);

        System.out.println("\n========================================");
        System.out.println("  Lab Complete");
        System.out.println("========================================");

        // Release DB connections and close the connection pool
        HibernateUtil.shutdown();
    }
}
