package com.lab.hibernate.dao;

import com.lab.hibernate.entity.Product;
import com.lab.hibernate.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

/**
 * ProductDAO.java
 * ---------------
 * Data Access Object (DAO) for the Product entity.
 *
 * The DAO pattern separates database logic from business logic.
 * All SQL is handled here; Main.java and other classes never touch SQL directly.
 *
 * CRUD operations provided:
 *   C – Create : insertProduct()
 *   R – Read   : getProductById(), getAllProducts()
 *   U – Update : updateProduct()
 *   D – Delete : deleteProduct()
 *
 * Each method follows the same Hibernate transaction pattern:
 *   1. Open a Session  (lightweight; wraps one DB connection)
 *   2. Begin a Transaction
 *   3. Perform the DB operation
 *   4. Commit (or rollback on error)
 *   5. Close the Session (try-with-resources handles this automatically)
 */
public class ProductDAO {

    // ══════════════════════════════════════════════════════════════════════
    //  CREATE
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Task 3 – Insert a new product record into the database.
     *
     * session.persist(entity) is the JPA-standard way to save a new object.
     * Hibernate generates and executes:  INSERT INTO products (name, ...) VALUES (...)
     *
     * After commit, Hibernate writes the generated primary key back into
     * the passed 'product' object, so product.getId() will return the new ID.
     *
     * @param product a new Product instance (id should be 0 / unset)
     */
    public void insertProduct(Product product) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.persist(product);  // INSERT INTO products (...)
            tx.commit();
            System.out.println("Inserted: " + product);
        } catch (Exception e) {
            if (tx != null) tx.rollback();  // undo partial changes on failure
            System.err.println("Insert failed: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  READ
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Task 4 – Retrieve a single product by its primary key (id).
     *
     * session.get(Class, id) queries:  SELECT * FROM products WHERE id = ?
     * Returns null if no matching row exists – safe to check without try/catch.
     *
     * Alternative: session.load(Class, id) – returns a proxy without hitting
     * the DB immediately (lazy), but throws ObjectNotFoundException if the
     * row is missing when the proxy is first accessed.
     *
     * @param id the primary key of the product to retrieve
     * @return the Product object, or null if not found
     */
    public Product getProductById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Product product = session.get(Product.class, id);  // SELECT by PK
            if (product != null) {
                System.out.println("Found: " + product);
            } else {
                System.out.println("No product found with id=" + id);
            }
            return product;
        } catch (Exception e) {
            System.err.println("Retrieve failed: " + e.getMessage());
            return null;
        }
    }

    /**
     * Retrieve ALL products from the database.
     *
     * Uses HQL (Hibernate Query Language):
     *   "FROM Product"  →  SELECT * FROM products
     *
     * HQL operates on entity class names ("Product"), not table names ("products").
     * This keeps queries database-agnostic (works with MySQL, H2, Oracle, etc.)
     *
     * @return list of all Product objects, or null on error
     */
    public List<Product> getAllProducts() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // createQuery(hql, resultType) – type-safe HQL query
            List<Product> products = session
                    .createQuery("FROM Product", Product.class)
                    .list();
            System.out.println("Total products found: " + products.size());
            return products;
        } catch (Exception e) {
            System.err.println("Retrieve all failed: " + e.getMessage());
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  UPDATE
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Task 5 – Update the price and quantity of an existing product.
     *
     * Hibernate uses "dirty checking":
     *   When session.get() loads an object, Hibernate takes a snapshot of it.
     *   At commit time, Hibernate compares the current state to the snapshot.
     *   If any field changed, Hibernate automatically issues an UPDATE – no
     *   explicit session.update() or session.save() call needed.
     *
     * Steps:
     *   1. session.get() – loads the product into "persistent" state.
     *   2. Modify fields using setters.
     *   3. tx.commit() – dirty checking detects changes → UPDATE issued.
     *
     * @param id          primary key of the product to update
     * @param newPrice    new unit price to set
     * @param newQuantity new stock quantity to set
     */
    public void updateProduct(int id, double newPrice, int newQuantity) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            Product product = session.get(Product.class, id);
            if (product != null) {
                product.setPrice(newPrice);       // change price
                product.setQuantity(newQuantity); // change quantity
                // Hibernate dirty-checking generates: UPDATE products SET price=?, quantity=? WHERE id=?
                tx.commit();
                System.out.println("Updated: " + product);
            } else {
                System.out.println("Update skipped – product id=" + id + " not found.");
                tx.rollback();
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Update failed: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  DELETE
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Task 6 – Delete a discontinued product by its ID.
     *
     * session.remove(entity) marks the object for deletion.
     * Hibernate generates:  DELETE FROM products WHERE id = ?
     * The SQL is flushed to the database when the transaction commits.
     *
     * Note: The object must be in "persistent" state (loaded in same session)
     * before calling remove(). That is why we call session.get() first.
     *
     * @param id primary key of the product to delete
     */
    public void deleteProduct(int id) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            Product product = session.get(Product.class, id);
            if (product != null) {
                session.remove(product);  // DELETE FROM products WHERE id=?
                tx.commit();
                System.out.println("Deleted product with id=" + id);
            } else {
                System.out.println("Delete skipped – product id=" + id + " not found.");
                tx.rollback();
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Delete failed: " + e.getMessage());
        }
    }
}
